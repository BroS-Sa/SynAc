t = 'London is the capital of the Great Britain'
t = '1'.join(t.split())
print (t)