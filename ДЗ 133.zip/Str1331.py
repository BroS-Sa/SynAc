slovo = input('Введите слово: ')
if slovo == slovo [::-1]:
    print ('True')
else:
    print ('False')