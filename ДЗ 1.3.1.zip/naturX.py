X = int(input('Введите натуральное число: '))
if X == 1:
    C = 1
else:
    C = 2
for i in range (2, int(X/2)):
    if X % i == 0:
        C += 1
print (C)