A = int(input ('Введите А: '))
B = int(input ('Введите B: '))
if A <= B:
    for i in range (A, B):
        if i % 2 == 0:
            print (i, end =' ')
else:
    print ('Не соблюдено условие A <= B')