N = int(input('Введите число'))
D = 0
for i in range (N):
    if int (input())==0:
        D += 1
        print (D)