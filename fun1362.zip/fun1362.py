
import collections

pets = dict()


def create ():
    if pets:
        # Добавил ID
        last = collections.deque(pets,maxlen=1)[0]
        new = last + 1
    else:
        new = 1
    name = input('Введите имя питомца: ')
    tip = input('Введите тип питомца: ')
    age = int(input('Введите возраст питомца: '))
    owner = input('Введите имя владельца: ')
    pets [new] = {'Имя: ': name, 'Вид: ': tip, 'Возраст: ': age, 'Владелец: ': owner}

def suffix(age):
    if 11 <= age % 100 <= 14:
        return f"{age} лет"
    elif age % 10 == 1:
        return f"{age} год"
    elif age % 10 in [2, 3, 4]:
        return f"{age} года"
    else:
        return f"{age} лет"
    
def delete(pet_id):
    if pet_id in pets:
        del pets[pet_id]
        print(f"Питомец с ID {pet_id} удален.")
    else:
        print("Питомец с таким ID не найден.")

def update(pet_id, name=None, tip=None, age=None):
    pet = pets.get(pet_id) 
    if pet: 
        if name:
            pet['name'] = name
        if tip:
            pet['tip'] = tip
        if age is not None:
            pet['age'] = age
        print(f"Информация о питомце с ID {pet_id} обновлена.")
    else:
        print(f"Питомец с ID {pet_id} не найден.")

def pets_id(pet_id):
    if pet_id in pets:
        print(pets[pet_id])
    else:
        print(False)

def read (id):
    print("Список питомцев")
    print("---------------")
    for pet in pets:
        print(f'Имя: {pets[id]['имя']}, Вид: {pets[id]["вид"]}, Возраст: {suffix(pets[id]["возраст"])}')

while True:
    command = input("Введите команду (или 'stop' для выхода) : ")
    if command.lower() == 'stop':
        print("Команда 'stop' получена. Завершение программы.")
    break
    
if command == 'create':  
    create()  
elif command == 'read':  
    a = int(input("Введите ID питомца: "))  
    print(read (a))  
if command == 'delete':  
    b = int(input("Введите ID питомца: "))  
    delete(b)  
if command == 'update':  
    c = int(input("Введите ID питомца: "))  
    name = input('Введите имя питомца: ')  
    species = input('Введите вид питомца: ')  
    age = int(input('Введите возраст питомца: '))  
    update(c, name, species, age)



   
   
   
