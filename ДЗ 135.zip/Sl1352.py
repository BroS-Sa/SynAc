A = {}
for b in range (10, -6, -1):
    A [b] = b ** b
print (A)