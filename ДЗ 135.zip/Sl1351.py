name = {}
pets = {}
a = input('Введите имя питмоца: ')
a1 = input('Введите вид питомца: ')
a2 = int(input('Введите возраст питомца: '))
a3 = input('Введите имя владельца: ')
pets = {'Вид питомца: ': a1, 'Возраст питомца: ': a2, 'Имя владельца: ': a3}
name [a] = pets
for key, value in name.items():
    kind = value['Вид питомца: ']
    old = value['Возраст питомца: ']
    name2 = value['Имя владельца: ']
    old1 = ''
    if old % 10 == 1 and old != 11 and old % 100 != 11:
        old1 = 'год'
    elif 1 < old % 10 <= 4 and old != 12 and old != 13 and old != 14:
        old1 = 'года'
    else:
        old1 = 'лет'
print ('Это', kind, 'по кличке',key,'. Возраст питомца: ',old, old1,'. Имя владедьца:', name2)