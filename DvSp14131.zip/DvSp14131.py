import random

matrix_1 = [[random.randint(-50,200) for k in range (10)] for k in range (10)]
matrix_2 = [[random.randint(-50,200) for k in range (10)] for k in range (10)]
matrix_3 = [[0 for k in range (10)] for k in range (10)]
for i in range (10):
    for j in range (10):
        matrix_3 [i][j] = matrix_1[i][j] + matrix_2[i][j]

for l in matrix_3:
    print(*l)