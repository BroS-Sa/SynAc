N = int(input())
A = []
for i in range (N):
    B = int(input())
    A.append (B)
    A.insert(0, A.pop())
print (*A)