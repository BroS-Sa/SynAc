
N =int(input('Введите число: '))
1 <= N <= 10000
A = []
for i in range (N):
    B = int(input())
    A.append (B)
    A.reverse
# Поискал варианты функции, т.к. print(*A.reverse) не работало
print (*A[::-1])
