x = int(input('Введите минимальную сумму инвестици: '))
A = int(input('Введите сумму у Майка: '))
B = int(input('Введите сумму у Ивана: '))
if (A >= x) and (B >= x):
    print ('2')
elif (A >= x) and (B < x):
    print ('Mike')
elif (A < x) and (B >= x):
    print ('Ivan')
elif (A < x) and (B < x) and (A + B) >= x:
    print ('1')
else:
    print ('0')