word = input('Введите слово: ')
# Посмотрел в дополнительной литературе функцию по счету букв в слове .count
aw = word.count ('a')
ew = word.count ('e')
iw = word.count ('i')
ow = word.count ('o')
uw = word.count ('u')
summa = aw + ew + iw + ow + uw
print ('Количество гласных:', summa)
if aw == 0:
    print ('a = false')
else:
    print ('a =', aw)
if ew == 0:
    print ('e = false')
else:
    print ('e =', ew)
if iw == 0:
    print ('i = false')
else:
    print ('a =', iw)
if ow == 0:
    print ('o = false')
else:
    print ('o =', ow)
if uw == 0:
    print ('u = false')
else:
    print ('u =', uw)